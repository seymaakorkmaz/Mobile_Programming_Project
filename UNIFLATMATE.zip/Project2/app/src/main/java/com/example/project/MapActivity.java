package com.example.project;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.ItemizedOverlayWithFocus;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
public class MapActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    MapView mapView;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    LocationListener locationListener;
    ProgressDialog progressDialog2;
    double curr_user_latitude,curr_user_longitude;
    Button find;
    Drawable drawable;
    double desired_distance;
    double selected_distance;
    List<TextMarker> markerList = new ArrayList<>();
    List<User> users = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        //menu and toolbar
        drawerLayout = findViewById(R.id.drawerLayoutMap);
        toolbar = findViewById(R.id.toolBarMap);
        toolbar.setTitle("MAP");
        toolbar.setTitleTextColor(Color.parseColor("#eceae5"));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.menu); // menü ikonu ayarla
        actionBar.setDisplayHomeAsUpEnabled(true); // toolbar'ı göster
        NavigationView navigationView = findViewById(R.id.nav_view_map);
        navigationView.setNavigationItemSelectedListener(MapActivity.this);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();


        SeekBar seekBar = findViewById(R.id.seekBar2);
        TextView textViewProgress = findViewById(R.id.textViewProgress);
        find = findViewById(R.id.find);

        mapView = findViewById(R.id.mapview);
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setBuiltInZoomControls(true);
        mapView.setMultiTouchControls(true);
        mapView.getController().setZoom(15.0);
        mapView.getController().setCenter(new GeoPoint(41.0247509831723, 28.891559310162403));
        Configuration.getInstance().load(getApplicationContext(), PreferenceManager.getDefaultSharedPreferences(getApplicationContext()));


        progressDialog2 = new ProgressDialog(this);
        progressDialog2.setMessage("Loading...");
        progressDialog2.setCancelable(false);
        progressDialog2.show();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                // Handle location updates here
                // Toast.makeText(UserProfileSettingsActivity.this, "Latitude: " + location.getLatitude() + ", Longitude: " + location.getLongitude(), Toast.LENGTH_SHORT).show();
            }

        };

        // Request location updates using LocationManager
        checkLocationPermissions();

        // Execute the LocationTask
        MapActivity.LocationTask locationTask = new MapActivity.LocationTask();
        locationTask.execute();

        RadioGroup radioGroup = findViewById(R.id.radio_group);
        RelativeLayout layout = findViewById(R.id.filter);
        layout.setVisibility(View.GONE);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_all) {
                    layout.setVisibility(View.GONE);
                    addUsersToMap(10000.0);
                } else if (checkedId == R.id.radio_filter) {
                    layout.setVisibility(View.VISIBLE);
                    seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            // Değer değiştiğinde yapılacak işlemler
                            desired_distance = progress;
                            textViewProgress.setText(String.valueOf(progress)+" km");
                            selected_distance = Double.parseDouble(String.valueOf(progress));
                            filterUsers(selected_distance);
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                            // Kaydırma işlemi başladığında yapılacak işlemler
                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            // Kaydırma işlemi bittiğinde yapılacak işlemler
                        }
                    });

                }
            }
        });

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addUsersToMap(selected_distance);
            }
        });

    }

    private void checkLocationPermissions() {
        if(ContextCompat.checkSelfPermission(MapActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MapActivity.this, new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION},100);

        }
    }

    public GeoPoint convertAddressToGeoPoint(Address address) {
        double latitude = address.getLatitude();
        double longitude = address.getLongitude();

        GeoPoint geoPoint = new GeoPoint(latitude, longitude);
        return geoPoint;
    }
    String value;
    private void addUsersToMap(double desired_distance) {

        mapView.getOverlays().clear();
        mapView.invalidate();

        //add ytu location
        Drawable image = getResources().getDrawable(R.drawable.pin2);

        TextMarker marker = new TextMarker(getApplicationContext(), mapView, "YTU DAVUTPAŞA", image,"#182351");
        marker.setPosition(new GeoPoint(41.0247509831723, 28.891559310162403));

        // Haritaya marker'ı ekleyin
        mapView.getOverlays().add(marker);


        //add current location
        Drawable image2 = getResources().getDrawable(R.drawable.pin3);

        marker = new TextMarker(getApplicationContext(), mapView, "YOU ARE HERE", image2,"#B32121");
        marker.setPosition(new GeoPoint(curr_user_latitude, curr_user_longitude));

        // Haritaya marker'ı ekleyin
        mapView.getOverlays().add(marker);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference newColRef = db.collection("users");
        Geocoder geocoder = new Geocoder(MapActivity.this, Locale.getDefault());

        FirebaseAuth mAuth= FirebaseAuth.getInstance();
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();
        String id = userAuth.getUid();

        newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // Sorgu başarılı oldu
                    QuerySnapshot querySnapshot = task.getResult();
                    ArrayList<User> users = new ArrayList<>();
                    ArrayList<CustomOverlayItem> overlayItems = new ArrayList<>();
                    for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {

                        // Doküman verilerini al ve kullan
                        Map<String, Object> data = documentSnapshot.getData();
                        if(!id.equals((String)  data.get("id"))){
                        int contact_preferences = Integer.parseInt(data.get("contact_preferences").toString());
                        int day = Integer.parseInt(data.get("day").toString());
                        System.out.println(day);
                        int department_item = Integer.parseInt(data.get("department_item").toString());
                        String email = (String) data.get("email");
                        String fullName = (String) data.get("fullName");
                        int grade_item = Integer.parseInt(data.get("grade_item").toString());
                        String imageUrl = (String) data.get("imageUrl");
                        float km = Float.parseFloat(data.get("km").toString());
                        String phone = (String) data.get("phoneNumber");
                        int situation = Integer.parseInt(data.get("situation").toString());
                        String address = (String) data.get("address");
                        String password = (String) data.get("password");
                        String verification_email = (String) data.get("verification_email");
                        String idd = (String) data.get("id");
                        String token = (String) data.get("token");
                        User user = new User(idd, fullName, email, phone, imageUrl, department_item, grade_item, situation, km, day, contact_preferences, address, verification_email, password, token);
                        users.add(user);
                        if (address != null) {
                            try {
                                List<Address> addresses = geocoder.getFromLocationName(address, 1);
                                if (addresses != null && !addresses.isEmpty()) {
                                    Address firstAddress = addresses.get(0);
                                    double latitude = firstAddress.getLatitude();
                                    double longitude = firstAddress.getLongitude();
                                    double distance = calculateDistance(curr_user_latitude, curr_user_longitude, latitude, longitude);
                                    System.out.println(distance + " " + desired_distance);
                                    if (distance <= desired_distance) {
                                        GeoPoint geoPoint = new GeoPoint(latitude, longitude);
                                        CustomOverlayItem overlayItem = new CustomOverlayItem(user, geoPoint, user.getFullName(), user.getPhoneNumber());
                                        // Using Glide to download the image and create a Drawable
                                        RequestOptions requestOptions = new RequestOptions().override(100, 100); // Set desired width and height
                                        Glide.with(MapActivity.this)
                                                .asBitmap()
                                                .load(user.getImageUrl())
                                                .apply(requestOptions)
                                                .into(new SimpleTarget<Bitmap>() {
                                                    @Override
                                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                                        drawable = new BitmapDrawable(getResources(), resource);

                                                        /*
                                                        System.out.println(user.getFullName());
                                                        TextMarker marker = new TextMarker(user, getApplicationContext(), mapView, fullName, drawable, "#000000", UserProfileActivity.class);
                                                        marker.setPosition(geoPoint);
                                                        markerList.add(marker);

                                                        // Haritaya marker'ı ekleyin
                                                        mapView.getOverlays().add(marker);*/
                                                        overlayItem.setMarker(drawable);

                                                    }
                                                });
                                        overlayItems.add(overlayItem);

                                    }

                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }


                    }
                    ItemizedOverlayWithFocus<CustomOverlayItem> overlay = new ItemizedOverlayWithFocus<>(
                            MapActivity.this, overlayItems, new ItemizedIconOverlay.OnItemGestureListener<CustomOverlayItem>() {
                        @Override
                        public boolean onItemSingleTapUp(int index, CustomOverlayItem item) {
                            User user = item.getUser();
                            openUserProfile(user);
                            return true;
                        }

                        @Override
                        public boolean onItemLongPress(int index, CustomOverlayItem item) {
                            return false;
                        }
                    });


                    mapView.getOverlays().add(overlay);
                    mapView.invalidate();


                }
            }
        });



    }

    public void filterUsers(double desired_distance){
        for (TextMarker marker : markerList) {

            double latitude = marker.getPosition().getLatitude();
            double longitude = marker.getPosition().getLongitude();
            double distance = calculateDistance(41.0247509831723, 28.891559310162403,latitude,longitude);

            if (distance > desired_distance) {
                marker.remove(mapView); // Silinecek marker'ları bir listeye ekle
            }
        }

    }
    LocationManager locationManager;
    private class LocationTask extends AsyncTask<Void, Void, Location> {
        @Override
        protected Location doInBackground(Void... voids) {
            try {
                // Wait for 5 seconds
                Thread.sleep(5000);

                // Get the last known location
                if (ActivityCompat.checkSelfPermission(MapActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    return locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); //NETWORK_PROVIDER
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Location location) {
            if (location != null) {
                // Handle the obtained location here
                curr_user_latitude = location.getLatitude();
                curr_user_longitude = location.getLongitude();
                addUsersToMap(10000.0);
                progressDialog2.dismiss();
            }
        }
    }
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double earthRadius = 6371; // Dünya yarıçapı (km)

        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double distance = earthRadius * c; // İki nokta arasındaki mesafe (km)

        return distance;
    }
    private void openUserProfile(User user) {
        Intent intent = new Intent(MapActivity.this, UserProfileActivity.class);
        intent.putExtra("User", user);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: // menü ikonuna tıklanmış
                drawerLayout.openDrawer(GravityCompat.START);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_users:
                Intent usersIntent = new Intent(this, UsersActivity.class);
                startActivity(usersIntent);

                break;
            case R.id.nav_map:
                recreate();
                break;
            case R.id.match:
                Intent matchIntent = new Intent(this, MatchRequestsActivity.class);
                startActivity(matchIntent);
                break;
            case R.id.nav_notifications:
                Intent notificationIntent = new Intent(this, NotificationsActivity.class);
                startActivity(notificationIntent);

                break;
            case R.id.nav_profile:
                FirebaseAuth mAuth;
                mAuth = FirebaseAuth.getInstance();
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                Intent intent = new Intent(MapActivity.this, UserProfileSettingsActivity.class);
                FirebaseUser userAuth = mAuth.getCurrentUser();
                String id = userAuth.getUid();
                System.out.println(id);
                DocumentReference docRef = db.collection("users").document(id);

                docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            // Doküman varsa, verileri al
                            Map<String, Object> data = documentSnapshot.getData();
                            int contact_preferences = Integer.parseInt(data.get("contact_preferences").toString());
                            int day = Integer.parseInt(data.get("day").toString());
                            System.out.println(day);
                            int department_item = Integer.parseInt(data.get("department_item").toString());
                            String email =(String) data.get("email");
                            String fullName = (String) data.get("fullName");
                            int grade_item = Integer.parseInt(data.get("grade_item").toString());
                            String imageUrl = (String) data.get("imageUrl");
                            float km = Float.parseFloat( data.get("km").toString());
                            String phone = (String) data.get("phoneNumber");
                            int situation =  Integer.parseInt(data.get("situation").toString());
                            String address = (String)  data.get("address");
                            String password = (String)  data.get("password");
                            String token = (String)  data.get("token");
                            String verification_email =(String) data.get("verification_email");

                            User u = new User(id,fullName,email,phone,imageUrl,department_item,grade_item, situation, km, day, contact_preferences,address,verification_email,password,token);

                            intent.putExtra("User",u);

                            startActivity(intent);

                        } else {
                            // Doküman bulunamadı
                        }
                    }
                });


                break;
            case R.id.nav_logout:

                AlertDialog.Builder builder = new AlertDialog.Builder(MapActivity.this);
                builder.setTitle("Save");
                builder.setMessage("Are you sure want to save?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        String device = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                        db.collection("sessions").document(device).delete()
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            FirebaseAuth.getInstance().signOut();
                                            startActivity(new Intent(MapActivity.this, MainActivity.class));
                                            finish();
                                            //  Log.d("Firestore", "Belge başarıyla silindi.");
                                        } else {
                                            // Log.d("Firestore", "Belge silinirken bir hata oluştu: " + task.getException());
                                        }
                                    }
                                });

                    }

                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });

                builder.show();

                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}