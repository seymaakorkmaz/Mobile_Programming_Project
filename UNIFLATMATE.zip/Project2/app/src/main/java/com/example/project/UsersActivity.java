package com.example.project;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Map;

public class UsersActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private RecyclerView recyclerView;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseAuth mAuth;
    Spinner situation;
    int desired_day;
    TextView share, stay;
    int sit;
    Button filter;
    ArrayList<User> users = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);


        mAuth = FirebaseAuth.getInstance();

        recyclerView = findViewById(R.id.user_recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        drawerLayout = findViewById(R.id.drawerLayoutUsers);
        toolbar = findViewById(R.id.toolBar);
        toolbar.setTitle("USERS");
        toolbar.setTitleTextColor(Color.parseColor("#9189A3"));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.menu); // menü ikonu ayarla
        actionBar.setDisplayHomeAsUpEnabled(true); // toolbar'ı göster

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();
        RadioGroup radioGroup = findViewById(R.id.radio_group);
        RelativeLayout layout = findViewById(R.id.filter);
        RelativeLayout day = findViewById(R.id.day);
        layout.setVisibility(View.GONE);
        SeekBar seekBar = findViewById(R.id.seekBar2);
        TextView textViewProgress = findViewById(R.id.textViewProgress);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_all) {
                    layout.setVisibility(View.GONE);
                    addAllUsers();
                } else if (checkedId == R.id.radio_filter) {
                    seekBar.setProgress(0);
                    situation.setSelection(0);
                    layout.setVisibility(View.VISIBLE);
                    seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            // Değer değiştiğinde yapılacak işlemler
                            desired_day = progress;
                            textViewProgress.setText(String.valueOf(progress)+" day(s)");

                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                            // Kaydırma işlemi başladığında yapılacak işlemler
                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            // Kaydırma işlemi bittiğinde yapılacak işlemler
                        }
                    });

                }
            }
        });

        addAllUsers();
        stay = findViewById(R.id.text);
        share = findViewById(R.id.text2);

        day.setVisibility(View.GONE);
        situation = findViewById(R.id.situation_spinner);
        situation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedText = parent.getItemAtPosition(position).toString();
                if (position == 1) {
                    day.setVisibility(View.VISIBLE);
                    stay.setVisibility(View.VISIBLE);
                    share.setVisibility(View.INVISIBLE);
                } else if (position == 2) {
                    day.setVisibility(View.VISIBLE);
                    stay.setVisibility(View.INVISIBLE);
                    share.setVisibility(View.VISIBLE);
                } else {
                    day.setVisibility(View.GONE);
                }
                sit = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




        filter = findViewById(R.id.filterButton);
        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterUsers(sit, desired_day);

            }
        });

    }

    public void addAllUsers(){
        users.clear();
        mAuth =FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();
        String id = userAuth.getUid();
        CollectionReference newColRef = db.collection("users");
        newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // Sorgu başarılı oldu
                    QuerySnapshot querySnapshot = task.getResult();

                    for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {

                        // Doküman verilerini al ve kullan
                        Map<String, Object> data = documentSnapshot.getData();
                        if(!id.equals((String)  data.get("id"))){
                            int contact_preferences = Integer.parseInt(data.get("contact_preferences").toString());
                            int day = Integer.parseInt(data.get("day").toString());
                            System.out.println(day);
                            int department_item = Integer.parseInt(data.get("department_item").toString());
                            String email =(String) data.get("email");
                            String fullName = (String) data.get("fullName");
                            int grade_item = Integer.parseInt(data.get("grade_item").toString());
                            String imageUrl = (String) data.get("imageUrl");
                            float km = Float.parseFloat( data.get("km").toString());
                            String phone = (String) data.get("phoneNumber");
                            int situation =  Integer.parseInt(data.get("situation").toString());
                            String address = (String)  data.get("address");
                            String password = (String)  data.get("password");
                            String verification_email =(String) data.get("verification_email");
                            String idd = (String)  data.get("id");
                            String token = (String)  data.get("token");
                            System.out.println(token+"TOOOKKEKNNN");
                            User u = new User(idd,fullName,email,phone,imageUrl,department_item,grade_item, situation, km, day, contact_preferences,address,verification_email,password,token);

                            users.add(u);
                        }



                    }
                    recyclerView.setAdapter(new UsersAdapter(users,UsersActivity.this));
                } else {
                    // Sorgu başarısız oldu
                    //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                }
            }
        });
    }
        public void filterUsers(int situation, int day){
            ArrayList<User>  u = new ArrayList<>();

            for(User user:users){
                if(situation == 0){
                    u.add(user);
                }else if(user.getSituation() == situation && user.getDay() <= day){
                    u.add(user);
                }
            }
            recyclerView.setAdapter(new UsersAdapter(u,UsersActivity.this));
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: // menü ikonuna tıklanmış
                drawerLayout.openDrawer(GravityCompat.START);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_users:
                recreate();

                break;
            case R.id.nav_map:
                Intent mediaIntent = new Intent(this, MapActivity.class);
                startActivity(mediaIntent);
                break;
            case R.id.match:
              Intent matchIntent = new Intent(this, MatchRequestsActivity.class);
               startActivity(matchIntent);
                break;
            case R.id.nav_notifications:
                Intent notificationIntent = new Intent(this, NotificationsActivity.class);
                startActivity(notificationIntent);

                break;
            case R.id.nav_profile:
                Intent intent = new Intent(UsersActivity.this, UserProfileSettingsActivity.class);
                FirebaseUser userAuth = mAuth.getCurrentUser();
                String id = userAuth.getUid();
                System.out.println(id);
                DocumentReference docRef = db.collection("users").document(id);

                docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            // Doküman varsa, verileri al
                            Map<String, Object> data = documentSnapshot.getData();
                            int contact_preferences = Integer.parseInt(data.get("contact_preferences").toString());
                            int day = Integer.parseInt(data.get("day").toString());
                            System.out.println(day);
                            int department_item = Integer.parseInt(data.get("department_item").toString());
                            String email =(String) data.get("email");
                            String fullName = (String) data.get("fullName");
                            int grade_item = Integer.parseInt(data.get("grade_item").toString());
                            String imageUrl = (String) data.get("imageUrl");
                            float km = Float.parseFloat( data.get("km").toString());
                            String phone = (String) data.get("phoneNumber");
                            int situation =  Integer.parseInt(data.get("situation").toString());
                            String address = (String)  data.get("address");
                            String password = (String)  data.get("password");
                            String token = (String)  data.get("token");
                            String verification_email =(String) data.get("verification_email");

                            User u = new User(id,fullName,email,phone,imageUrl,department_item,grade_item, situation, km, day, contact_preferences,address,verification_email,password,token);

                            intent.putExtra("User",u);

                            startActivity(intent);

                        } else {
                            // Doküman bulunamadı
                        }
                    }
                });


                break;
            case R.id.nav_logout:

                AlertDialog.Builder builder = new AlertDialog.Builder(UsersActivity.this);
                builder.setTitle("Save");
                builder.setMessage("Are you sure want to save?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        String device = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                        db.collection("sessions").document(device).delete()
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            FirebaseAuth.getInstance().signOut();
                                            startActivity(new Intent(UsersActivity.this, MainActivity.class));
                                            finish();
                                          //  Log.d("Firestore", "Belge başarıyla silindi.");
                                        } else {
                                           // Log.d("Firestore", "Belge silinirken bir hata oluştu: " + task.getException());
                                        }
                                    }
                                });

                    }

                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });

                builder.show();

                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}