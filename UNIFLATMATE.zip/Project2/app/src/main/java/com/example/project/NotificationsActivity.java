package com.example.project;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Map;

public class NotificationsActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    RecyclerView recyclerView;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ArrayList<Match> matches = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);


        drawerLayout = findViewById(R.id.drawerLayoutNotifications);
        toolbar = findViewById(R.id.toolBar);
        toolbar.setTitle("NOTIFICATIONS");
        toolbar.setTitleTextColor(Color.parseColor("#9189A3"));
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.menu); // menü ikonu ayarla
        actionBar.setDisplayHomeAsUpEnabled(true); // toolbar'ı göster

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        CollectionReference newColRef = db.collection("matches");

        newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // Sorgu başarılı oldu
                    QuerySnapshot querySnapshot = task.getResult();

                    FirebaseUser userAuth = FirebaseAuth.getInstance().getCurrentUser();
                    String id = userAuth.getUid();

                    for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {
                        // Doküman verilerini al ve kullan
                        Map<String, Object> data = documentSnapshot.getData();
                        if(Integer.parseInt(data.get("seen").toString()) == 0){

                            String documentId = documentSnapshot.getId();
                            String sender = (String) data.get("sender_id");
                            System.out.println(sender);
                            String receiver = (String) data.get("receiver_id");
                            String date = (String) data.get("date");
                            String hour = (String) data.get("hour");
                            int situation = Integer.parseInt(data.get("situation").toString());
                            int seen = Integer.parseInt(data.get("seen").toString());

                            Match match = new Match(id,sender,receiver,situation,date,hour,seen);
                            matches.add(match);

                            // Dosyanın "seen" değerini güncelle
                            documentSnapshot.getReference().update("seen", 1)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            // Güncelleme başarılı olduğunda yapılacak işlemler
                                            System.out.println("seen değeri güncellendi");
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            // Güncelleme başarısız olduğunda yapılacak işlemler
                                            System.out.println("seen değeri güncellenirken hata oluştu: " + e.getMessage());
                                        }
                                    });
                        }

                    }
                    recyclerView.setAdapter(new AcceptRejectAdapter(matches,NotificationsActivity.this));
                } else {
                    // Sorgu başarısız oldu
                    //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                }
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: // menü ikonuna tıklanmış
                drawerLayout.openDrawer(GravityCompat.START);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_users:
                Intent usersIntent = new Intent(this, UsersActivity.class);
                startActivity(usersIntent);

                break;
            case R.id.nav_map:
                Intent mediaIntent = new Intent(this, MapActivity.class);
                startActivity(mediaIntent);
                break;
            case R.id.match:
                Intent matchIntent = new Intent(this, MatchRequestsActivity.class);
                startActivity(matchIntent);
                break;
            case R.id.nav_notifications:
                Intent notificationIntent = new Intent(this, NotificationsActivity.class);
                startActivity(notificationIntent);

                break;
            case R.id.nav_profile:
                FirebaseAuth mAuth;
                mAuth = FirebaseAuth.getInstance();
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                Intent intent = new Intent(NotificationsActivity.this, UserProfileSettingsActivity.class);
                FirebaseUser userAuth = mAuth.getCurrentUser();
                String id = userAuth.getUid();
                System.out.println(id);
                DocumentReference docRef = db.collection("users").document(id);

                docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            // Doküman varsa, verileri al
                            Map<String, Object> data = documentSnapshot.getData();
                            int contact_preferences = Integer.parseInt(data.get("contact_preferences").toString());
                            int day = Integer.parseInt(data.get("day").toString());
                            System.out.println(day);
                            int department_item = Integer.parseInt(data.get("department_item").toString());
                            String email =(String) data.get("email");
                            String fullName = (String) data.get("fullName");
                            int grade_item = Integer.parseInt(data.get("grade_item").toString());
                            String imageUrl = (String) data.get("imageUrl");
                            float km = Float.parseFloat( data.get("km").toString());
                            String phone = (String) data.get("phoneNumber");
                            int situation =  Integer.parseInt(data.get("situation").toString());
                            String address = (String)  data.get("address");
                            String password = (String)  data.get("password");
                            String token = (String)  data.get("token");
                            String verification_email =(String) data.get("verification_email");

                            User u = new User(id,fullName,email,phone,imageUrl,department_item,grade_item, situation, km, day, contact_preferences,address,verification_email,password,token);

                            intent.putExtra("User",u);

                            startActivity(intent);

                        } else {
                            // Doküman bulunamadı
                        }
                    }
                });


                break;
            case R.id.nav_logout:

                AlertDialog.Builder builder = new AlertDialog.Builder(NotificationsActivity.this);
                builder.setTitle("Save");
                builder.setMessage("Are you sure want to save?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        String device = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                        db.collection("sessions").document(device).delete()
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            FirebaseAuth.getInstance().signOut();
                                            startActivity(new Intent(NotificationsActivity.this, MainActivity.class));
                                            finish();
                                            //  Log.d("Firestore", "Belge başarıyla silindi.");
                                        } else {
                                            // Log.d("Firestore", "Belge silinirken bir hata oluştu: " + task.getException());
                                        }
                                    }
                                });

                    }

                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });

                builder.show();

                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}

