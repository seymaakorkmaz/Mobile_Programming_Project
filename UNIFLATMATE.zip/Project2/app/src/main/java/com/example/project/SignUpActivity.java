package com.example.project;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.util.Calendar;

public class SignUpActivity extends AppCompatActivity {


    EditText name, username, email,  password, confirmpassword, year_of_entry, year_of_graduate;
    Spinner education_type;
    Button signup;
    TextView loginRedirect;
    ImageView imageView;
    FloatingActionButton camera_button;
    //create object ıf DatabaseReference class to access firebase's Realtime Database
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");
    FirebaseStorage storage;
    FirebaseAuth mAuth;
    StorageTask uploadTask;

    StorageReference storageRef;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();


    ActivityResultLauncher activityResultLauncher;
    Uri mImageUri;
    String myUri ="";
    Uri uri;
    private void checkPermissions(){
        boolean res1 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED;
        boolean res2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED;

        if(!(res1 || res2)){
            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE},101);
        }else{
            launchImagePicker();
        }
    }

    private void launchImagePicker() {
        com.github.dhaval2404.imagepicker.ImagePicker.with(SignUpActivity.this)
                .crop()
                .compress(1024)
                .maxResultSize(1080,1080)
                .start();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uri = data.getData();
        imageView.setImageURI(uri);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        name = findViewById(R.id.signupname);
        email = findViewById(R.id.signupemail);
        password = findViewById(R.id.signuppassword);
        confirmpassword = findViewById(R.id.signupconfirmpassword);
        loginRedirect = findViewById(R.id.loginRedirectText);
        signup = findViewById(R.id.signupbutton);

        imageView = findViewById(R.id.image_view);
        camera_button = findViewById(R.id.floatingActionButton);


        storage = FirebaseStorage.getInstance();
        mAuth =FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("users");
        storageRef = FirebaseStorage.getInstance().getReference().child("profile pic");

        camera_button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(View v) {
                checkPermissions();
     //           launchImagePicker();

            }
        });
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);

        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                //get data from editText into String variables
                final String name_txt = name.getText().toString();
                final String email_txt = email.getText().toString();
                final String password_txt = password.getText().toString();
                final String confirmpassword_txt = confirmpassword.getText().toString();


                //check if user fill all the fields before sending data to firebase
                int flag = 0;
                if (name_txt.isEmpty()) {
                    name.setError("Name cannot be empty");
                    name.requestFocus();
                    flag = 1;
                }
                if (email_txt.isEmpty()) {
                    email.setError("Email cannot be empty");
                    email.requestFocus();
                    flag = 1;
                }

                if (password_txt.isEmpty()) {
                    password.setError("Password cannot be empty");
                    password.requestFocus();
                    flag = 1;
                }

                if (confirmpassword_txt.isEmpty()) {
                    confirmpassword.setError("Confirm your password");
                    confirmpassword.requestFocus();
                    flag = 1;
                }


                if (flag == 1) {
                    Toast.makeText(SignUpActivity.this, "Please fill al the fields!!", Toast.LENGTH_SHORT).show();
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email_txt).matches()) {
                    email.setError("Invalid email");
                    email.requestFocus();
                } else if (password_txt.length() < 6) {
                    password.setError("Invalid password format. Password must be at least 6 characters long");
                    password.requestFocus();
                } else if (!password_txt.equals(confirmpassword_txt)) {
                    Toast.makeText(SignUpActivity.this, "Passswords are not matching!!", Toast.LENGTH_SHORT).show();
                    password.setText("");
                    confirmpassword.setText("");

                }else if(!email_txt.endsWith("std.yildiz.edu.tr")){
                    Toast.makeText(SignUpActivity.this, "You must register with your 'std.yildiz.edu.tr' e-mail address", Toast.LENGTH_SHORT).show();
                    email.setError("Invalid email");
                }

                else if (uri != null) {

                    mAuth.createUserWithEmailAndPassword(email_txt, password_txt).addOnSuccessListener(new OnSuccessListener<AuthResult>() {

                        @Override
                        public void onSuccess(AuthResult authResult) {
                            progressDialog.show();
                            FirebaseUser userAuth = mAuth.getCurrentUser();
                            String id = userAuth.getUid();

                            DocumentReference newDocRef = db.collection("users").document(id);

                            Calendar calendar = Calendar.getInstance(); // Anlık tarih ve saat bilgisi
                            int year = calendar.get(Calendar.YEAR); // Yıl bilgisi
                            int month = calendar.get(Calendar.MONTH); // Ay bilgisi (0 - 11)
                            int day = calendar.get(Calendar.DAY_OF_MONTH); // Ayın günü bilgisi
                            int hour = calendar.get(Calendar.HOUR_OF_DAY); // Saat bilgisi (24 saat formatı)
                            int minute = calendar.get(Calendar.MINUTE); // Dakika bilgisi
                            int second = calendar.get(Calendar.SECOND); // Saniye bilgisi
                            StorageReference userPhotosRef = storageRef.child(id + year + "-" + (month + 1) + "-" + day + " " + hour + ":" + minute + ":" + second + ".jpg");
                            uploadTask = userPhotosRef.putFile(uri);

                            uploadTask.continueWithTask(new Continuation() {
                                @Override
                                public Object then(@NonNull Task task) throws Exception {
                                    if (!task.isSuccessful()) {
                                        throw task.getException();
                                    }
                                    return userPhotosRef.getDownloadUrl();
                                }
                            }).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull Task task) {
                                    if (task.isSuccessful()) {
                                        Uri downloadUrl = (Uri) task.getResult();
                                        myUri = downloadUrl.toString();

                                        // Kullanıcının Firebase Messaging token'ını al
                                        firebaseMessaging.getToken()
                                                .addOnCompleteListener(tokenTask -> {
                                                    if (tokenTask.isSuccessful()) {
                                                        // Token başarıyla alındı
                                                        String token = tokenTask.getResult();
                                                        User user = new User(id, name_txt,email_txt,password_txt,myUri,token);
                                                        System.out.println(token);

                                                        newDocRef.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void unused) {
                                                                progressDialog.dismiss();

                                                                startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                                                                finish();
                                                            }
                                                        }).addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                // Kayıt işlemi başarısız, kullanıcıya hata mesajı gösterilebilir.
                                                                Toast.makeText(SignUpActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                                            }
                                                        });

                                                    } else {
                                                        // Token alınamadı
                                                        System.out.println("Token alınamadı.");
                                                    }
                                                });




                                    }
                                }
                            });

                            FirebaseUser user = mAuth.getCurrentUser();

                        }

                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                            Toast.makeText(SignUpActivity.this, "Registration failed, this email is already registered", Toast.LENGTH_SHORT).show();
                        }
                    });


                } else {
                    Toast.makeText(SignUpActivity.this, "Image field cannot be left blank", Toast.LENGTH_SHORT).show();
                }

            }
        });


        loginRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this,MainActivity.class));
            }
        });

    }
}