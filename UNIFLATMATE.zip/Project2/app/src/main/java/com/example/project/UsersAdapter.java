package com.example.project;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.UsersViewHolder>{

    private ArrayList<User> userList;
    private Context context;


    public UsersAdapter(ArrayList<User> users, Context context) {
        super();
        this.userList = users;
        this.context = context;
    }

    @NonNull
    @Override
    public UsersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.user_list_items, parent, false);
        return new UsersAdapter.UsersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersViewHolder holder, int position) {
        User user = userList.get(position);

        holder.fullName.setText(user.getFullName());
       // Virgül ile ayrılmış parçalara bölmek
        if(user.getAddress() != null){
            String[] parts = user.getAddress().split(","); // Virgül karakterine göre adresi böl
            String[] parts2 = parts[parts.length - 1].split(" ");
            // Son parçadaki boşlukları kaldır ve il/ilçe bilgisini al
            String ilIlce = parts2[parts2.length-1].trim();
            holder.location.setText(ilIlce);
        }else{
            System.out.println("null değil");
        }


        int arrayResourceId = R.array.options;

        // Diziyi alır
        String[] sit_array = context.getResources().getStringArray(arrayResourceId);

        if(user.getSituation() == 0){
            holder.situation.setText("");

        }else{
            holder.situation.setText(sit_array[user.getSituation()]);

        }


        String imageUrl = user.getImageUrl();
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.person); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(context)
                .setDefaultRequestOptions(requestOptions)
                .load(imageUrl)
                .into(holder.image);


    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class UsersViewHolder extends RecyclerView.ViewHolder {

        TextView fullName, location, situation;
        ImageView image;
        CardView cardView;


        public UsersViewHolder(@NonNull View itemView) {
            super(itemView);
            fullName = itemView.findViewById(R.id.user_fullname);
            location = itemView.findViewById(R.id.user_location);
            situation = itemView.findViewById(R.id.user_situation);
            image = itemView.findViewById(R.id.user_image);


            cardView = itemView.findViewById(R.id.user_cardView);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    User user = userList.get(getAdapterPosition());

                    Intent intent = new Intent(context, UserProfileActivity.class);
                    intent.putExtra("User",user);
                    context.startActivity(intent);

                }
            });
        }
    }
}
