package com.example.project;

import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {
    String id;
    String fullName;
    String email, phoneNumber;
    String password;
    String imageUrl;

   // Location location;
    int department_item, grade_item;
    int situation;
    float km;
    int day;
    int contact_preferences; //0:wp , 1: mail, 2: both, 3: none
    String address;
    String verification_email;
    String token;
    public void setId(String id) {
        this.id = id;
    }

    public String getVerification_email() {
        return verification_email;
    }

    public void setVerification_email(String verification_email) {
        this.verification_email = verification_email;
    }


    public User(String fullName, String email, String imageUrl) {
        this.fullName = fullName;
        this.email = email;
        this.imageUrl = imageUrl;
    }

    public User(String id, String fullName, String email, String phoneNumber, String imageUrl, int department_item, int grade_item, int situation, float km, int day, int contact_preferences, String address,String verification_email, String password, String token) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.imageUrl = imageUrl;
        this.department_item = department_item;
        this.grade_item = grade_item;
        this.situation = situation;
        this.km = km;
        this.day = day;
        this.contact_preferences = contact_preferences;
        this.address = address;
        this.verification_email = verification_email;
        this.password = password;
        this.token = token;
    }

    public User(String id, String fullName, String email, String phoneNumber, String imageUrl, int department_item, int grade_item, int situation, float km, int day, int contact_preferences) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.imageUrl = imageUrl;
        this.department_item = department_item;
        this.grade_item = grade_item;
        this.situation = situation;
        this.km = km;
        this.day = day;
        this.contact_preferences = contact_preferences;

    }

    public User(String id, String fullName, String email, String password, String imageUrl,String token) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.imageUrl = imageUrl;
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getId() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getDepartment_item() {
        return department_item;
    }

    public void setDepartment_item(int department_item) {
        this.department_item = department_item;
    }

    public int getGrade_item() {
        return grade_item;
    }

    public void setGrade_item(int grade_item) {
        this.grade_item = grade_item;
    }

    public int getSituation() {
        return situation;
    }

    public void setSituation(int situation) {
        this.situation = situation;
    }

    public float getKm() {
        return km;
    }

    public void setKm(float km) {
        this.km = km;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getContact_preferences() {
        return contact_preferences;
    }

    public void setContact_preferences(int contact_preferences) {
        this.contact_preferences = contact_preferences;
    }
    // Parcelable implementation
    protected User(Parcel in) {
        id = in.readString();
        fullName = in.readString();
        email = in.readString();
        phoneNumber = in.readString();
        password = in.readString();
        imageUrl = in.readString();
        department_item = in.readInt();
        grade_item = in.readInt();
        situation = in.readInt();
        km = in.readFloat();
        day = in.readInt();
        contact_preferences = in.readInt();
        address = in.readString();
        verification_email = in.readString();
        password = in.readString();
        token = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(fullName);
        dest.writeString(email);
        dest.writeString(phoneNumber);
        dest.writeString(password);
        dest.writeString(imageUrl);
        dest.writeInt(department_item);
        dest.writeInt(grade_item);
        dest.writeInt(situation);
        dest.writeFloat(km);
        dest.writeInt(day);
        dest.writeInt(contact_preferences);
        // address bilgilerini yaz
        dest.writeString(address);
        dest.writeString(verification_email);
        dest.writeString(password);
        dest.writeString(token);
    }
}
