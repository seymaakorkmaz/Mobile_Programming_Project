package com.example.project;

public class Session {
    String user_id;
    String device_id;
    String user_email;
    String user_password;

    public Session(String user_id, String device_id, String user_email, String user_password) {
        this.user_id = user_id;
        this.device_id = device_id;
        this.user_email = user_email;
        this.user_password = user_password;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getDevice_id() {
        return device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }
}
