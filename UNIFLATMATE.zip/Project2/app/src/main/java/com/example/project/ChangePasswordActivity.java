package com.example.project;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class ChangePasswordActivity extends AppCompatActivity {

    EditText email, old_pass, new_pass, new_pass2;
    Button save;
    int flag = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        email = findViewById(R.id.email);
        old_pass = findViewById(R.id.oldpas);
        new_pass = findViewById(R.id.newpas);
        new_pass2 = findViewById(R.id.newpas2);

        save = findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!new_pass.getText().toString().equals(new_pass2.getText().toString())){

                    Toast.makeText(ChangePasswordActivity.this, "Passwords are not the same", Toast.LENGTH_SHORT).show();
                    new_pass.setError("Passwords are not match");
                    new_pass2.setError("Passwords are not match");
                }else if(new_pass.getText().toString().length() < 6) {
                    Toast.makeText(ChangePasswordActivity.this, "Invalid password format. Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();

                }else{


                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    CollectionReference newColRef = db.collection("users");
                    newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                // Sorgu başarılı oldu
                                QuerySnapshot querySnapshot = task.getResult();
                                FirebaseAuth mAuth = FirebaseAuth.getInstance();
                                for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {

                                    // Doküman verilerini al ve kullan
                                    Map<String, Object> data = documentSnapshot.getData();
                                    String id = (String) data.get("id");
                                    String email_txt = (String) data.get("email");
                                    String password = (String) data.get("password");
                                    String verification_email = (String) data.get("verification_email");

                                    if(email.getText().toString().equals(email_txt)){
                                        if(password.equals(old_pass.getText().toString())){
                                            FirebaseAuth.getInstance().signInWithEmailAndPassword(email_txt, password)
                                                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                                        @Override
                                                        public void onSuccess(AuthResult authResult) {
                                                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                                            String id = user.getUid();
                                                            user.updatePassword(new_pass.getText().toString())
                                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {
                                                                            if (task.isSuccessful()) {
                                                                                Map<String, Object> updates = new HashMap<>();
                                                                                updates.put("password", new_pass.getText().toString());
                                                                                db.collection("users").document(id)
                                                                                        .update(updates)
                                                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                                            @Override
                                                                                            public void onSuccess(Void aVoid) {
                                                                                                if(verification_email != null ){
                                                                                                    System.out.println("VERIFICATION"+verification_email);
                                                                                                    FirebaseAuth.getInstance().signInWithEmailAndPassword(verification_email, password)
                                                                                                            .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                                                                                                @Override
                                                                                                                public void onSuccess(AuthResult authResult) {
                                                                                                                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                                                                                                                    user.updatePassword(new_pass.getText().toString())
                                                                                                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                                                                                @Override
                                                                                                                                public void onComplete(@NonNull Task<Void> task) {
                                                                                                                                    if (task.isSuccessful()) {


                                                                                                                                        // Şifre güncelleme işlemi başarılı
                                                                                                                                    } else {
                                                                                                                                        // Şifre güncelleme işlemi başarısız
                                                                                                                                        Toast.makeText(ChangePasswordActivity.this, "Şifre güncelleme işlemi başarısız oldu.", Toast.LENGTH_SHORT).show();
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            });

                                                                                                                }
                                                                                                            }).addOnFailureListener(new OnFailureListener() {
                                                                                                                @Override
                                                                                                                public void onFailure(@NonNull Exception e) {

                                                                                                                }
                                                                                                            });
                                                                                                }

                                                                                                Toast.makeText(ChangePasswordActivity.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                                                                                                Context context = getApplicationContext();

                                                                                                startActivity(new Intent(context, MainActivity.class));
                                                                                                finish();
                                                                                            }
                                                                                        })
                                                                                        .addOnFailureListener(new OnFailureListener() {
                                                                                            @Override
                                                                                            public void onFailure(@NonNull Exception e) {
                                                                                                //  Log.d(TAG, "Şifre güncelleme başarısız oldu: " + e.getMessage());
                                                                                            }
                                                                                        });
                                                                                // Şifre güncelleme işlemi başarılı
                                                                            } else {
                                                                                // Şifre güncelleme işlemi başarısız
                                                                                Toast.makeText(ChangePasswordActivity.this, "Password update failed.", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        }
                                                                    });



                                                        }
                                                    }).addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {

                                                        }
                                                    });

                                        }else{
                                            Toast.makeText(ChangePasswordActivity.this, "Wrong password!", Toast.LENGTH_SHORT).show();
                                        }







                                    }
                                }



                            } else {
                                // Sorgu başarısız oldu
                                //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                            }
                        }
                    });
                }






            }
        });




    }
}