package com.example.project;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;

import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

public class TextMarker extends Marker {
    private String text;
    private Paint paint;
    private Drawable image;
    private Context context;
    private Class<?> targetActivity;

    private User user;
    private OnMarkerClickListener listener;
    String color;


    public TextMarker(User user,Context context, MapView mapView, String text, Drawable image, String color, Class<?> targetActivity) {
        super(mapView);
        this.user = user;
        this.text = text;
        this.image = image;
        this.context = context;
        this.targetActivity = targetActivity;

        // Yazı stili ayarları
        paint = new Paint();
        paint.setTextSize(30);
        paint.setAntiAlias(true);
        paint.setTextAlign(Paint.Align.CENTER);

        paint.setColor(Color.parseColor(color)); // Yazı rengini kırmızı olarak ayarlayın
    }

    public TextMarker(User user, Context context, MapView mapView, String text, Drawable image, String color) {
        super(mapView);
        this.user = user;
        this.text = text;
        this.image = image;

        // Yazı stili ayarları
        paint = new Paint();
        paint.setTextSize(30);
        paint.setAntiAlias(true);
        paint.setTextAlign(Paint.Align.CENTER);

        paint.setColor(Color.parseColor(color)); // Yazı rengini kırmızı olarak ayarlayın
    }
    public TextMarker( Context context, MapView mapView, String text, Drawable image, String color) {
        super(mapView);
        this.user = user;
        this.text = text;
        this.image = image;


        // Yazı stili ayarları
        paint = new Paint();
        paint.setTextSize(30);
        paint.setAntiAlias(true);
        paint.setTextAlign(Paint.Align.CENTER);

        paint.setColor(Color.parseColor(color)); // Yazı rengini kırmızı olarak ayarlayın
    }
/*
    @Override
    public boolean onSingleTapConfirmed(final MotionEvent event, final MapView mapView) {
        // Marker'a tıklandığında yapılacak işlemler
        if (targetActivity != null) {
            Intent intent = new Intent(context, targetActivity);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Add this line to set the flag
            intent.putExtra("User", this.user);
            context.startActivity(intent);
        }

        // true döndürerek olayın tüketildiğini belirtin
        return true;
    }*/

    @Override
    public void draw(Canvas canvas, MapView mapView, boolean shadow) {
        // Çizimi kaydet
        canvas.save();

        // Görseli çiz
        if (image != null) {
            int x = mapView.getProjection().toPixels(getPosition(), null).x;
            int y = mapView.getProjection().toPixels(getPosition(), null).y;

            int imageWidth = image.getIntrinsicWidth();
            int imageHeight = image.getIntrinsicHeight();

            // Görseli markerın altında konumlandırın
            image.setBounds(x - imageWidth / 2, y - imageHeight, x + imageWidth / 2, y);
            image.draw(canvas);
        }

        // Konum adını çiz
        canvas.drawText(text, mapView.getProjection().toPixels(getPosition(), null).x,
                mapView.getProjection().toPixels(getPosition(), null).y +26, paint);

        // Konumu ayarla (örneğin, 10 piksel yukarıya kaydır)
       // canvas.translate(0, -10);

        // Çizimi geri yükle
        canvas.restore();
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Paint getPaint() {
        return paint;
    }

    public void setPaint(Paint paint) {
        this.paint = paint;
    }

    @Override
    public Drawable getImage() {
        return image;
    }

    @Override
    public void setImage(Drawable image) {
        this.image = image;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
