package com.example.project;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;

public class UserProfileActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    TextView fullName,email, phone, department, grade,situation, location, km,day,edit_km,edit_day;
    TextView looking_house_km, looking_roommate_km;
    TextView looking_house_day, looking_roommate_day;
    ImageView image;
    ImageView wp,mail;
    FirebaseAuth mAuth;
    RelativeLayout day_layout, km_layout;
    Button match ;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        Intent intent = getIntent();
        User user = intent.getParcelableExtra("User");

        drawerLayout = findViewById(R.id.drawerLayoutUserProfile);
        toolbar = findViewById(R.id.toolBar);
        toolbar.setTitle(user.getFullName());
        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.menu); // menü ikonu ayarla
        actionBar.setDisplayHomeAsUpEnabled(true); // toolbar'ı göster

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();

        fullName = findViewById(R.id.fullName);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        department = findViewById(R.id.department);
        grade = findViewById(R.id.grade);
        situation = findViewById(R.id.situation);
        location = findViewById(R.id.location);
        image = findViewById(R.id.user_image);
        wp = findViewById(R.id.wp);
        mail = findViewById(R.id.gmail);
        match = findViewById(R.id.matchButton);

        looking_house_km = findViewById(R.id.desired);
        looking_roommate_km = findViewById(R.id.present);
        looking_house_day = findViewById(R.id.desired_time);
        looking_roommate_day = findViewById(R.id.present_time);
        km = findViewById(R.id.km);
        day = findViewById(R.id.day);
        edit_km = findViewById(R.id.km_edit);
        edit_day = findViewById(R.id.day_edit);
        day_layout = findViewById(R.id.day_layout);
        km_layout = findViewById(R.id.km_layout);

        fullName.setText(user.getFullName());
        email.setText(user.getEmail());
        phone.setText(user.getPhoneNumber());
        location.setText(user.getAddress());

        String[] dep_array = getResources().getStringArray(R.array.department_array);
        if(user.getDepartment_item() == 0){
            department.setText("");
        }else{
            department.setText(dep_array[user.getDepartment_item()]);
        }


        String[] grade_array = getResources().getStringArray(R.array.grades);
        if(user.getGrade_item() == 0){
            grade.setText("");
        }else{
            grade.setText(grade_array[user.getGrade_item()]);
        }


        String[] sit_array = getResources().getStringArray(R.array.options);
        if(user.getSituation() == 0){
            situation.setText("");
        }else{
            situation.setText(sit_array[user.getSituation()]);
        }


        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.person2); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(UserProfileActivity.this)
                .setDefaultRequestOptions(requestOptions)
                .load(user.getImageUrl())
                .into(image);


        if(user.getContact_preferences() == 0){
            wp.setVisibility(View.GONE);
            mail.setVisibility(View.GONE);
        }else if(user.getContact_preferences() == 1){
            wp.setVisibility(View.VISIBLE);
            mail.setVisibility(View.GONE);
        }else if(user.getContact_preferences() == 2){
            mail.setVisibility(View.VISIBLE);
            wp.setVisibility(View.GONE);
        }else if(user.getContact_preferences() == 3){
            mail.setVisibility(View.VISIBLE);
            wp.setVisibility(View.VISIBLE);
        }

        wp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = user.getPhoneNumber();
                String message = "Merhaba!"; // İletilecek mesajı buraya girin

                try {
                    Uri uri = Uri.parse("https://api.whatsapp.com/send?phone=" + phoneNumber + "&text=" + URLEncoder.encode(message, "UTF-8"));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    // Hata durumunda işlem yapabilirsiniz
                }
            }

        });

        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipientEmail = user.getEmail();
                         // Alıcı e-posta adresini buraya girin
                String subject = "Match Request";  // E-posta konusunu buraya girin
                String body = "Hello,\n\nHow are you?";  // E-posta içeriğini buraya girin

                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:" + recipientEmail));
                intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                intent.putExtra(Intent.EXTRA_TEXT, body);

                startActivity(Intent.createChooser(intent, "E-posta göndermek için bir uygulama seçin"));
            }
        });

        if (user.getSituation() == 1) {
            day_layout.setVisibility(View.VISIBLE);
            km_layout.setVisibility(View.VISIBLE);
            looking_house_km.setVisibility(View.VISIBLE); // TextView'ı görünür yap
            looking_roommate_km.setVisibility(View.INVISIBLE);
            looking_house_day.setVisibility(View.VISIBLE); // TextView'ı görünür yap
            looking_roommate_day.setVisibility(View.INVISIBLE);
            edit_km.setVisibility(View.VISIBLE);
            km.setVisibility(View.VISIBLE);
            edit_day.setVisibility(View.VISIBLE);
            day.setVisibility(View.VISIBLE);
            edit_km.setText(String.valueOf(user.getKm()));
            edit_day.setText(String.valueOf(user.getDay()));
        } else if (user.getSituation() == 2) {
            day_layout.setVisibility(View.VISIBLE);
            km_layout.setVisibility(View.VISIBLE);
            looking_house_km.setVisibility(View.INVISIBLE); // TextView'ı görünür yap
            looking_roommate_km.setVisibility(View.VISIBLE);
            looking_house_day.setVisibility(View.VISIBLE); // TextView'ı görünür yap
            looking_roommate_day.setVisibility(View.INVISIBLE);
            edit_km.setVisibility(View.VISIBLE);
            km.setVisibility(View.VISIBLE);
            edit_day.setVisibility(View.VISIBLE);
            day.setVisibility(View.VISIBLE);
            edit_km.setEnabled(false);
            edit_km.setText(String.valueOf(user.getKm()));
            edit_km.setText(String.valueOf(user.getKm()));
            edit_day.setText(String.valueOf(user.getDay()));
        } else {
            day_layout.setVisibility(View.GONE);
            km_layout.setVisibility(View.GONE);
            looking_house_km.setVisibility(View.GONE); // TextView'ı görünür yap
            looking_roommate_km.setVisibility(View.GONE);
            looking_house_day.setVisibility(View.GONE); // TextView'ı görünür yap
            looking_roommate_day.setVisibility(View.GONE);
            edit_km.setVisibility(View.GONE);
            km.setVisibility(View.GONE);
            edit_day.setVisibility(View.GONE);
            day.setVisibility(View.GONE);
        }
        View popupView = getLayoutInflater().inflate(R.layout.popup_layout, null);

        // Pop-up'ı gösterecek olan PopupWindow nesnesini oluştur
        PopupWindow popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        int backgroundColor = Color.parseColor("#9189A3");
        popupWindow.setBackgroundDrawable(new ColorDrawable(backgroundColor));
        Button closePopupButton = popupView.findViewById(R.id.close_button);
        closePopupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Popup'ı kapat
                popupWindow.dismiss();
            }
        });
        match.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                if(user.getSituation() != 3){
                    mAuth =FirebaseAuth.getInstance();
                    FirebaseUser userAuth = mAuth.getCurrentUser();
                    String id = userAuth.getUid();
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    DocumentReference userRef = db.collection("users").document(id);

                    userRef.get().addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {

                                // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                                Map<String, Object> userData = document.getData();
                                String sender = (String) userData.get("fullName");

                                // userData içinde kullanıcı verilerini kullanabilirsiniz
                                String targetUserToken = user.getToken();
                                CollectionReference newColRef = db.collection("matches");
                                newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()) {
                                            // Sorgu başarılı oldu
                                            QuerySnapshot querySnapshot = task.getResult();

                                            for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {

                                                // Doküman verilerini al ve kullan
                                                Map<String, Object> data = documentSnapshot.getData();
                                                if(id.equals((String)  data.get("sender_id")) && user.getId().equals((String)  data.get("receiver_id")) && Integer.parseInt(data.get("situation").toString()) == 0){

                                                    flag = 1;
                                                    TextView text = popupView.findViewById(R.id.text);
                                                    TextView header = popupView.findViewById(R.id.header);
                                                    text.setText("You already have a pending request sent to this user");
                                                    header.setText("NOTICE");
                                                    popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
                                                    //Toast.makeText(UserProfileActivity.this, "You already have a pending request sent to this user", Toast.LENGTH_SHORT).show();

                                                }

                                            }
                                            if(flag==0){

                                                String title = "Match Request";
                                                String body =  sender + " sent a match request.";

                                                FCMSend.pushNotification(UserProfileActivity.this,
                                                        targetUserToken,
                                                        title,
                                                        body);
                                                Calendar calendar = Calendar.getInstance();
                                                SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
                                                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
                                                String formattedDate = dateFormat.format(calendar.getTime());
                                                String formattedTime = timeFormat.format(calendar.getTime());
                                                Match match = new Match(id, user.getId(),0, formattedDate,formattedTime, 0);
                                                System.out.println("MARAABAAA"+match.getId());
                                                //situation -> 0: bekliyor, 1: kabul edildi, 2: reddedildi

                                                DocumentReference newDocRef = db.collection("matches").document();
                                                newDocRef.set(match).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void unused) {
                                                        flag = 1;
                                                        Toast.makeText(UserProfileActivity.this, "Match Request Sent", Toast.LENGTH_SHORT).show();
                                                    }
                                                }).addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {

                                                    }
                                                });
                                            }




                                        } else {
                                            // Sorgu başarısız oldu
                                            //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                                        }
                                    }
                                });



                            } else {
                                // Kullanıcı belirli ID'ye sahip değil
                            }
                        } else {
                            // Sorgu başarısız oldu
                        }
                    });

                }else{
                    TextView text = popupView.findViewById(R.id.text);
                    TextView header = popupView.findViewById(R.id.header);
                    text.setText("You cannot send a match request because this user is not looking for a housemate or house.");
                    header.setText("NOTICE");
                    popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);
                   // Toast.makeText(UserProfileActivity.this, , Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: // menü ikonuna tıklanmış
                drawerLayout.openDrawer(GravityCompat.START);
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_users:
                Intent usersIntent = new Intent(this, UsersActivity.class);
                startActivity(usersIntent);

                break;
            case R.id.nav_map:
                Intent mediaIntent = new Intent(this, MapActivity.class);
                startActivity(mediaIntent);
                break;
            case R.id.match:
                Intent matchIntent = new Intent(this, MatchRequestsActivity.class);
                startActivity(matchIntent);
                break;
            case R.id.nav_notifications:
                Intent notificationIntent = new Intent(this, NotificationsActivity.class);
                startActivity(notificationIntent);

                break;
            case R.id.nav_profile:
                Intent intent = new Intent(UserProfileActivity.this, UserProfileSettingsActivity.class);
                FirebaseUser userAuth = mAuth.getCurrentUser();
                String id = userAuth.getUid();
                System.out.println(id);
                DocumentReference docRef = db.collection("users").document(id);

                docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            // Doküman varsa, verileri al
                            Map<String, Object> data = documentSnapshot.getData();
                            int contact_preferences = Integer.parseInt(data.get("contact_preferences").toString());
                            int day = Integer.parseInt(data.get("day").toString());
                            System.out.println(day);
                            int department_item = Integer.parseInt(data.get("department_item").toString());
                            String email =(String) data.get("email");
                            String fullName = (String) data.get("fullName");
                            int grade_item = Integer.parseInt(data.get("grade_item").toString());
                            String imageUrl = (String) data.get("imageUrl");
                            float km = Float.parseFloat( data.get("km").toString());
                            String phone = (String) data.get("phoneNumber");
                            int situation =  Integer.parseInt(data.get("situation").toString());
                            String address = (String)  data.get("address");
                            String password = (String)  data.get("password");
                            String token = (String)  data.get("token");
                            String verification_email =(String) data.get("verification_email");

                            User u = new User(id,fullName,email,phone,imageUrl,department_item,grade_item, situation, km, day, contact_preferences,address,verification_email,password,token);

                            intent.putExtra("User",u);

                            startActivity(intent);

                        } else {
                            // Doküman bulunamadı
                        }
                    }
                });


                break;
            case R.id.nav_logout:

                AlertDialog.Builder builder = new AlertDialog.Builder(UserProfileActivity.this);
                builder.setTitle("Save");
                builder.setMessage("Are you sure want to save?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                        String device = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                        db.collection("sessions").document(device).delete()
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            FirebaseAuth.getInstance().signOut();
                                            startActivity(new Intent(UserProfileActivity.this, MainActivity.class));
                                            finish();
                                            //  Log.d("Firestore", "Belge başarıyla silindi.");
                                        } else {
                                            // Log.d("Firestore", "Belge silinirken bir hata oluştu: " + task.getException());
                                        }
                                    }
                                });

                    }

                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });

                builder.show();

                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
