package com.example.project;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.views.overlay.OverlayItem;

public class CustomOverlayItem extends OverlayItem {

    private User user;
    private String title;
    private String snippet;

    public CustomOverlayItem(User user, IGeoPoint geoPoint, String title, String snippet) {
        super(title, snippet, geoPoint);
        this.user = user;

    }

    public User getUser() {
        return user;
    }

    public String getTitle() {
        return title;
    }

    public String getSnippet() {
        return snippet;
    }


}