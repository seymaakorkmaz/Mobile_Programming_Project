package com.example.project;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    Button signin;
    TextView registerRedirect, forgotPassword;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private String currentUserId;
    private String deviceID, currentUserEmail, currentUserPassword;

    private static final int PERMISSION_REQUEST_CODE = 1001;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    int flag =0;

    private boolean checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
       return true;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission is granted
                // Perform your desired actions here
            } else {
                // Permission is denied
                // Handle the case where the user denies the permission
            }
        }
    }


    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = findViewById(R.id.signinemail);
        password = findViewById(R.id.signinpassword);
        signin = findViewById(R.id.signinbutton);
        registerRedirect = findViewById(R.id.registerRedirectText);
        forgotPassword = findViewById(R.id.forgot);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);

        if (checkNotificationPermission()) {
            // Permission is already granted
            // Perform your desired actions here
        } else {
            requestNotificationPermission();
        }

        mAuth = FirebaseAuth.getInstance();
        String device = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
        CollectionReference newColRef = db.collection("sessions");
        newColRef.document(device).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        startActivity(new Intent(MainActivity.this, UsersActivity.class));
                        finish();
                       // login(document.get("user_email").toString(),document.get("user_password").toString());
                        Log.d("Firestore", "Belge mevcut.");
                    } else {

                        Log.d("Firestore", "Belge mevcut değil.");
                    }
                } else {
                    Log.d("Firestore", "Belge kontrol edilirken bir hata oluştu: " + task.getException());
                }
            }
        });

            signin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    final String email_txt = email.getText().toString();
                    final String password_txt = password.getText().toString();
                    if (email_txt.isEmpty()) {
                        email.setError("Enter your email");
                    } /*else if (!Patterns.EMAIL_ADDRESS.matcher(email_txt).matches()) {
                    email.setError("Invalid email");
                } */else if (password_txt.isEmpty()) {
                        password.setError("Enter your email");
                    } else {
                        progressDialog.show();
                        login(email_txt,password_txt);

                    }
                }
            });

            registerRedirect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //open sign up activity
                    startActivity(new Intent(MainActivity.this, SignUpActivity.class));
                }
            });

            forgotPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, ChangePasswordActivity.class));
                }
            });
        }


        public void login(String email_text, String password_text){
            mAuth.signInWithEmailAndPassword(email_text, password_text)
                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            progressDialog.dismiss();
                            FirebaseUser userAuth = mAuth.getCurrentUser();
                            String id = userAuth.getUid();
                            Toast.makeText(MainActivity.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                            FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance();
                            // Kullanıcının Firebase Messaging token'ını al
                            firebaseMessaging.getToken()
                                    .addOnCompleteListener(tokenTask -> {
                                        if (tokenTask.isSuccessful()) {

                                            deviceID = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

                                            saveDeviceSession(id, deviceID, email_text, password_text);
                                            // Token başarıyla alındı
                                            String token = tokenTask.getResult();
                                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                                            DocumentReference newDocRef = db.collection("users").document(id);
                                            newDocRef.update("token",token);

                                        } else {
                                            // Token alınamadı
                                            System.out.println("Token alınamadı.");
                                        }
                                    });
                            startActivity(new Intent(MainActivity.this, UsersActivity.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            email.setText("");
                            password.setText("");
                            Toast.makeText(MainActivity.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
                        }
                    });

        }
    private void saveDeviceSession(String id, String device_id, String user_email, String user_password) {

        DocumentReference newDocRef = db.collection("sessions").document(device_id);
        Session session = new Session(id, device_id, user_email,user_password);
        newDocRef.set(session).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                System.out.println("UNUSUED"+device_id);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Kayıt işlemi başarısız, kullanıcıya hata mesajı gösterilebilir.
            }
        });
    }

/*
    @Override
    protected void onDestroy() {
        super.onDestroy();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String device = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
        db.collection("sessions").document(device).delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            FirebaseAuth.getInstance().signOut();
                            //  Log.d("Firestore", "Belge başarıyla silindi.");
                        } else {
                            // Log.d("Firestore", "Belge silinirken bir hata oluştu: " + task.getException());
                        }
                    }
                });

        }
*/
}
