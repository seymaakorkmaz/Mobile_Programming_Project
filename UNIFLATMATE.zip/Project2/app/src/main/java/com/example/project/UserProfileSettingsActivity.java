package com.example.project;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.SignInMethodQueryResult;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
public class UserProfileSettingsActivity extends AppCompatActivity implements LocationListener {
    EditText email, phone,verification_email;
    Button save;
    ImageView image;
    TextView fullName;
    FloatingActionButton camera;
    Button location;
    Spinner department, grade, situation;
    RadioButton wp, mail;
    TextView looking_house_km, looking_roommate_km;
    TextView looking_house_day, looking_roommate_day;
    TextView location_text;
    TextView km, day;
    EditText edit_km, edit_day;
    RelativeLayout km_layout, day_layout;
    String address = "";


    FirebaseStorage storage;
    FirebaseAuth mAuth;

    StorageTask uploadTask;
    FirebaseUser ver_user;
    StorageReference storageRef;
    float km_txt = 0.0f ;
    int day_txt, contact;
    ProgressDialog progressDialog2;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    int dep, grad, sit;
    Uri uri;
    String myUri = "";
    int wpp,maill;
    Location campus;
    final int FINE_PERMISSION_CODE=1;
    GoogleMap myMap;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    List<Address> addresses;
    int verified;
    private LocationManager locationManager;
    private LocationListener locationListener;
    Toolbar toolbar;

    private void checkPermissions() {
        boolean res1 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        boolean res2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

        if (!(res1 && res2)) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
        } else {
            launchImagePicker();
        }
    }


    private void launchImagePicker() {
        com.github.dhaval2404.imagepicker.ImagePicker.with(UserProfileSettingsActivity.this)
                .crop()
                .compress(1024)
                .maxResultSize(1080, 1080)
                .start();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uri = data.getData();
        image.setImageURI(uri);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_user_profile_settings);

        Intent intent = getIntent();
        User user = intent.getParcelableExtra("User");
        mAuth = FirebaseAuth.getInstance();
        toolbar = findViewById(R.id.toolBar);
        toolbar.setTitle("PROFILE SETTINGS");
        toolbar.setTitleTextColor(Color.parseColor("#9189A3"));
        setSupportActionBar(toolbar);

        looking_house_km = findViewById(R.id.desired);
        looking_roommate_km = findViewById(R.id.present);
        looking_house_day = findViewById(R.id.desired_time);
        looking_roommate_day = findViewById(R.id.present_time);
        km = findViewById(R.id.km);
        day = findViewById(R.id.day);

        fullName = findViewById(R.id.fullName);
        email = findViewById(R.id.user_email);
        verification_email = findViewById(R.id.ver_email);
        phone = findViewById(R.id.grad_phone);
        save = findViewById(R.id.save_profile);
        image = findViewById(R.id.image);
        camera = findViewById(R.id.open_camera);
        department = findViewById(R.id.department_spinner);
        grade = findViewById(R.id.grade_spinner);
        situation = findViewById(R.id.situation_spinner);
        location = findViewById(R.id.loc);
        wp = findViewById(R.id.wp);
        mail = findViewById(R.id.mail);
        edit_km = findViewById(R.id.km_edit);
        edit_day = findViewById(R.id.day_edit);
        location_text = findViewById(R.id.location_text);
        km_layout = findViewById(R.id.km_layout);
        day_layout = findViewById(R.id.day_layout);

        fullName.setText(user.getFullName());
        email.setText(user.getEmail());
        phone.setText(user.getPhoneNumber());
        location_text.setText(user.getAddress());
        department.setSelection(user.getDepartment_item());
        grade.setSelection(user.getGrade_item());
        situation.setSelection(user.getSituation());
        String campus_address = "Çifte Havuzlar, YTÜ-Davutpaşa Kampüsü, 34220 Esenler/İstanbul, Türkiye";
        Geocoder geocoder = new Geocoder(UserProfileSettingsActivity.this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocationName(campus_address, 1);
        } catch (IOException e) {


            throw new RuntimeException(e);
        }
        if (addresses != null && !addresses.isEmpty()) {
            Address firstAddress = addresses.get(0);
            double latitude = firstAddress.getLatitude();
            double longitude = firstAddress.getLongitude();
            campus = new Location("Custom");
            campus.setLatitude(latitude);
            campus.setLongitude(longitude);
            // Elde edilen Location nesnesini kullanabilirsiniz
        } else {
            // Adrese karşılık gelen konum bulunamadı
        }


        if (user.getContact_preferences() == 1) {

            wp.setChecked(true);
        } else if (user.getContact_preferences() == 2) {
            mail.setChecked(true);
        } else if (user.getContact_preferences() == 3) {
            wp.setChecked(true);
           mail.setChecked(true);

        }
        wp.setEnabled(true);
        mail.setEnabled(true);

        wp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                wp.setChecked(!wp.isChecked());
                return !wp.isChecked();
            }
        });

        mail.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mail.setChecked(!mail.isChecked());
                return !mail.isChecked();
            }
        });

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.person); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(UserProfileSettingsActivity.this)
                .setDefaultRequestOptions(requestOptions)
                .load(user.getImageUrl())
                .into(image);


        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        situation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedText = parent.getItemAtPosition(position).toString();
                if (position == 1) {
                    km_layout.setVisibility(View.VISIBLE);
                    day_layout.setVisibility(View.VISIBLE);
                    looking_house_km.setVisibility(View.VISIBLE); // TextView'ı görünür yap
                    looking_roommate_km.setVisibility(View.INVISIBLE);
                    looking_house_day.setVisibility(View.VISIBLE); // TextView'ı görünür yap
                    looking_roommate_day.setVisibility(View.INVISIBLE);
                    edit_km.setVisibility(View.VISIBLE);
                    km.setVisibility(View.VISIBLE);
                    edit_day.setVisibility(View.VISIBLE);
                    day.setVisibility(View.VISIBLE);
                    edit_km.setText(String.valueOf(user.getKm()));
                    edit_km.setText(String.valueOf(user.getKm()));
                    edit_km.setEnabled(true);
                    edit_day.setText(String.valueOf(user.getDay()));
                } else if (position == 2) {
                    km_layout.setVisibility(View.VISIBLE);
                    day_layout.setVisibility(View.VISIBLE);
                    looking_house_km.setVisibility(View.INVISIBLE); // TextView'ı görünür yap
                    looking_roommate_km.setVisibility(View.VISIBLE);
                    looking_house_day.setVisibility(View.VISIBLE); // TextView'ı görünür yap
                    looking_roommate_day.setVisibility(View.INVISIBLE);
                    edit_km.setVisibility(View.VISIBLE);
                    km.setVisibility(View.VISIBLE);
                    edit_day.setVisibility(View.VISIBLE);
                    edit_km.setEnabled(false);
                    day.setVisibility(View.VISIBLE);
                    System.out.println(km_txt);
                    if(km_txt != 0.0f){
                        System.out.println("farklı");
                        edit_km.setText(String.valueOf(km_txt));
                    }else{
                        edit_km.setText(String.valueOf(user.getKm()));
                    }

                    edit_day.setText(String.valueOf(user.getDay()));
                } else {
                    km_layout.setVisibility(View.GONE);
                    day_layout.setVisibility(View.GONE);
                    looking_house_km.setVisibility(View.GONE); // TextView'ı görünür yap
                    looking_roommate_km.setVisibility(View.GONE);
                    looking_house_day.setVisibility(View.GONE); // TextView'ı görünür yap
                    looking_roommate_day.setVisibility(View.GONE);
                    edit_km.setVisibility(View.GONE);
                    km.setVisibility(View.GONE);
                    edit_day.setVisibility(View.GONE);
                    day.setVisibility(View.GONE);
                }
                sit = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        if(!user.getAddress().equals("")){
            try {
                System.out.println(user.getAddress());
                List<Address> addresses2 = geocoder.getFromLocationName( user.getAddress(), 1);
                if (addresses2 != null && !addresses2.isEmpty()) {
                    Address firstAddress = addresses2.get(0);
                    double latitude = firstAddress.getLatitude();
                    double longitude = firstAddress.getLongitude();
                    System.out.println(campus.getLatitude()+","+ campus.getLongitude()+","+latitude+","+ longitude);
                    km_txt = (float) calculateDistance(campus.getLatitude(), campus.getLongitude(), latitude, longitude);

                    System.out.println("SELAMMMM"+km_txt);
                }


            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("EQUAL");
        }




        department.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dep = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Spinner'da hiçbir şey seçilmediğinde yapılacak işlemler burada yer alabilir
            }
        });


        grade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                grad = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Spinner'da hiçbir şey seçilmediğinde yapılacak işlemler burada yer alabilir
            }
        });
        TextView textView = findViewById(R.id.verify);
        if(user.getVerification_email() != null){
            if(!user.getVerification_email().equals("")){
                System.out.println(user.getEmail());
                verification_email.setText(user.getVerification_email());
                FirebaseAuth.getInstance().signInWithEmailAndPassword(user.getVerification_email(), user.getPassword())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Oturum açma işlemi başarılı.
                                    ver_user = FirebaseAuth.getInstance().getCurrentUser();
                                    if (ver_user != null) {
                                        if (ver_user.isEmailVerified()) {
                                            verification_email.setEnabled(false);
                                            textView.setVisibility(View.INVISIBLE);
                                            verified = 1;
                                        } else {
                                            verification_email.setEnabled(true);
                                            textView.setVisibility(View.VISIBLE);
                                            verified = 0;
                                        }
                                    }
                                    FirebaseAuth.getInstance().signOut();
                                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email.getText().toString(), user.getPassword());
                                } else {
                                    // Oturum açma işlemi başarısız.
                                }
                            }

                        });

            }else{
                textView.setVisibility(View.VISIBLE);
            }
        }


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(UserProfileSettingsActivity.this);
                builder.setTitle("Save");
                builder.setMessage("Are you sure want to save?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String pattern = "^\\+905\\d{9}$";
                        if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                            email.setError("Email is invaid");
                            //       Toast.makeText(SignUpActivity.this, ,Toast.LENGTH_SHORT).show();
                        } else if(!phone.getText().toString().equals("") && !phone.getText().toString().matches(pattern)) {
                                Toast.makeText(UserProfileSettingsActivity.this,  "You must enter the phone number in +905xxxxxxxxx format!"   ,Toast.LENGTH_SHORT).show();

                        }else{

                            String email_txt = email.getText().toString();
                            String phone_txt = phone.getText().toString();
                            String ver_email_txt = verification_email.getText().toString();
                            System.out.println(ver_email_txt);


                            location = findViewById(R.id.loc);
                            wp = findViewById(R.id.wp);
                            mail = findViewById(R.id.mail);
                            edit_km = findViewById(R.id.km_edit);
                            edit_day = findViewById(R.id.day_edit);

                            if (sit != 3) {
                                km_txt = Float.parseFloat(edit_km.getText().toString());
                                day_txt = Integer.parseInt(edit_day.getText().toString());
                            } else {
                                km_txt = 0;
                                day_txt = 0;
                            }

                            if (wp.isChecked() && mail.isChecked()) {
                                contact = 3;
                            } else if (mail.isChecked()) {
                                contact = 2;
                            } else if (wp.isChecked()) {
                                contact = 1;
                            } else {
                                contact = 0;
                            }

                            if(!ver_email_txt.equals("")){
                                mAuth.fetchSignInMethodsForEmail(ver_email_txt).addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {
                                        if (task.isSuccessful()) {
                                            SignInMethodQueryResult result = task.getResult();
                                            List<String> signInMethods = result.getSignInMethods();

                                            if (signInMethods != null && !signInMethods.isEmpty()) {
                                                System.out.println("VARR");
                                                // Kullanıcı mevcut, giriş yöntemleri listesinde var

                                            } else {

                                                FirebaseAuth.getInstance().createUserWithEmailAndPassword(ver_email_txt, user.getPassword())
                                                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<AuthResult> task) {
                                                                if (task.isSuccessful()) {
                                                                    // Oturum açma işlemi başarılı.
                                                                    ver_user = FirebaseAuth.getInstance().getCurrentUser();
                                                                    if (ver_user != null) {
                                                                        ver_user.sendEmailVerification()
                                                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                                    @Override
                                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                                        if (task.isSuccessful()) {
                                                                                            Toast.makeText(getApplicationContext(), "Email verification code sent. Please check your e-mail address.",
                                                                                                    Toast.LENGTH_SHORT).show();
                                                                                            FirebaseAuth.getInstance().signOut();
                                                                                            FirebaseAuth.getInstance().signInWithEmailAndPassword(email_txt, user.getPassword());


                                                                                        } else {
                                                                                            // E-posta doğrulama e-postası gönderme hatası.
                                                                                        }
                                                                                    }
                                                                                });
                                                                    }
                                                                } else {
                                                                    // Oturum açma işlemi başarısız.
                                                                }
                                                            }
                                                        });
                                            }
                                        } else {
                                            // Sorgu başarısız oldu
                                            // Hata durumunu işleyebilirsiniz
                                        }
                                    }
                                });


                            }

                            storageRef = FirebaseStorage.getInstance().getReference().child("profile pic");
                            Calendar calendar = Calendar.getInstance(); // Anlık tarih ve saat bilgisi
                            int year = calendar.get(Calendar.YEAR); // Yıl bilgisi
                            int month = calendar.get(Calendar.MONTH); // Ay bilgisi (0 - 11)
                            int day = calendar.get(Calendar.DAY_OF_MONTH); // Ayın günü bilgisi
                            int hour = calendar.get(Calendar.HOUR_OF_DAY); // Saat bilgisi (24 saat formatı)
                            int minute = calendar.get(Calendar.MINUTE); // Dakika bilgisi
                            int second = calendar.get(Calendar.SECOND); // Saniye bilgisi


                            if (uri != null) {
                                StorageReference userPhotosRef = storageRef.child(year + "-" + (month + 1) + "-" + day + " " + hour + ":" + minute + ":" + second + user.getId() + ".jpg");
                                uploadTask = userPhotosRef.putFile(uri);

                                uploadTask.continueWithTask(new Continuation() {
                                    @Override
                                    public Object then(@NonNull Task task) throws Exception {
                                        if (!task.isSuccessful()) {
                                            throw task.getException();
                                        }
                                        return userPhotosRef.getDownloadUrl();
                                    }
                                }).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if (task.isSuccessful()) {
                                            Uri downloadUrl = (Uri) task.getResult();
                                            myUri = downloadUrl.toString();
                                            User u = new User(user.getId(), user.getFullName(), email_txt, phone_txt, myUri, dep, grad, sit, km_txt, day_txt, contact,location_text.getText().toString(),ver_email_txt,user.getPassword(),user.getToken());

                                            DocumentReference newDocRef = db.collection("users").document(user.getId());
                                            newDocRef.set(u).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {

                                                    Toast.makeText(UserProfileSettingsActivity.this, "Update Completed", Toast.LENGTH_SHORT).show();
                                                    Context context = getApplicationContext();
                                                    Intent intent = new Intent(context, UsersActivity.class);
                                                    intent.putExtra("User", u);
                                                    startActivity(intent);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    // Kayıt işlemi başarısız, kullanıcıya hata mesajı gösterilebilir.
                                                    Toast.makeText(UserProfileSettingsActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    }
                                });
                            } else {
                                User u = new User(user.getId(), user.getFullName(), email_txt, phone_txt, user.getImageUrl(), dep, grad, sit, km_txt, day_txt, contact,location_text.getText().toString(),ver_email_txt,user.getPassword(),user.getToken());

                                DocumentReference newDocRef = db.collection("users").document(user.getId());
                                newDocRef.set(u).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(UserProfileSettingsActivity.this, "Profile information updated", Toast.LENGTH_SHORT).show();
                                        Context context = getApplicationContext();
                                        Intent intent = new Intent(context, UsersActivity.class);
                                        intent.putExtra("User", u);
                                        startActivity(intent);

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(UserProfileSettingsActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }

                        }

                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });

                builder.show();


            }

        });


        camera.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(View v) {
                checkPermissions();
                launchImagePicker();

            }
        });
        progressDialog2 = new ProgressDialog(this);
        progressDialog2.setMessage("Getting Location...");
        progressDialog2.setCancelable(false);

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog2.show();
                // Initialize LocationManager and LocationListener
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                locationListener = new LocationListener() {
                    @Override
                    public void onLocationChanged(@NonNull Location location) {
                        // Handle location updates here
                        // Toast.makeText(UserProfileSettingsActivity.this, "Latitude: " + location.getLatitude() + ", Longitude: " + location.getLongitude(), Toast.LENGTH_SHORT).show();
                    }

                };

                // Request location updates using LocationManager
                checkLocationPermissions();

                // Execute the LocationTask
                UserProfileSettingsActivity.LocationTask locationTask = new UserProfileSettingsActivity.LocationTask();
                locationTask.execute();


            }


        });


    }

    private class LocationTask extends AsyncTask<Void, Void, Location> {
        @Override
        protected Location doInBackground(Void... voids) {
            try {
                // Wait for 5 seconds
                Thread.sleep(5000);
                // Get the last known location
                if (ActivityCompat.checkSelfPermission(UserProfileSettingsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    return locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); //NETWORK_PROVIDER
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Location location) {
            System.out.println("LOCATION");
            if (location != null) {
                System.out.println("OF");
                // Handle the obtained location here
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                System.out.println(latitude+","+longitude);
                // Get the address from the obtained location
                Geocoder geocoder = new Geocoder(UserProfileSettingsActivity.this, Locale.getDefault());
                List<Address> addresses;
                try {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1);
                    if (addresses.size() > 0) {
                        address = addresses.get(0).getAddressLine(0);
                        System.out.println(address);
                        // Set the address to the TextView
                        location_text.setText(address);

                        km_txt = (float) calculateDistance(location.getLatitude(),location.getLongitude(),campus.getLatitude(),campus.getLongitude());


                        if(situation.getSelectedItemPosition() == 2){
                            edit_km.setText(String.valueOf(km_txt));
                        }

                        progressDialog2.dismiss();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                // Failed to get location
                progressDialog2.dismiss();
                Toast.makeText(UserProfileSettingsActivity.this, "Failed to get location! Open your location!", Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void checkLocationPermissions() {
      if(ContextCompat.checkSelfPermission(UserProfileSettingsActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
    ActivityCompat.requestPermissions(UserProfileSettingsActivity.this, new String[]{
        android.Manifest.permission.ACCESS_FINE_LOCATION},100);

      }
    }
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double earthRadius = 6371; // Dünya yarıçapı (km)

        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        double distance = earthRadius * c; // İki nokta arasındaki mesafe (km)

        return distance;
    }
    @Override
    public void onLocationChanged(@NonNull Location location) {

    }


    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        LocationListener.super.onStatusChanged(provider, status, extras);
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        LocationListener.super.onProviderEnabled(provider);
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        LocationListener.super.onProviderDisabled(provider);
    }
}