package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Map;

public class SentMatchAdapter extends RecyclerView.Adapter<SentMatchAdapter.SentMatchViewHolder>{

    private ArrayList<Match> matchList;
    private Context context;

    public SentMatchAdapter(ArrayList<Match> matchList, Context context) {
        super();
        this.matchList = matchList;
        this.context = context;
    }
    @NonNull
    @Override
    public SentMatchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.sent_match_list_items, parent, false);
        return new SentMatchAdapter.SentMatchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SentMatchViewHolder holder, int position) {
        Match match = matchList.get(position);
        if(match.getSituation() == 0){
            holder.wait.setVisibility(View.VISIBLE);
            holder.accept.setVisibility(View.INVISIBLE);
            holder.reject.setVisibility(View.INVISIBLE);
        }else if(match.getSituation() == 1){
            holder.wait.setVisibility(View. INVISIBLE);
            holder.accept.setVisibility(View.VISIBLE);
            holder.reject.setVisibility(View.INVISIBLE);
        }else{
            holder.wait.setVisibility(View. INVISIBLE);
            holder.accept.setVisibility(View.INVISIBLE);
            holder.reject.setVisibility(View.VISIBLE);
        }
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();
        String id = userAuth.getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(match.getReceiver_id());

        userRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {

                    // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                    Map<String, Object> userData = document.getData();
                    holder.fullName.setText((String) userData.get("fullName"));
                    RequestOptions requestOptions = new RequestOptions();
                    requestOptions.placeholder(R.drawable.person2); // isteğe bağlı bir yer tutucu görsel ayarlandı
                    requestOptions.fitCenter();
                    Glide.with(context)
                            .setDefaultRequestOptions(requestOptions)
                            .load((String) userData.get("imageUrl"))
                            .into(holder.image);

                } else {
                    // Kullanıcı belirli ID'ye sahip değil
                }
            } else {
                // Sorgu başarısız oldu
            }
        });
    }

    @Override
    public int getItemCount() {
        return matchList.size();
    }

    public class SentMatchViewHolder extends RecyclerView.ViewHolder {

        TextView fullName,wait, accept, reject;
        ImageView image;
        CardView cardView;


        public SentMatchViewHolder(@NonNull View itemView) {
            super(itemView);
            fullName = itemView.findViewById(R.id.user_fullname);
            accept = itemView.findViewById(R.id.accept);
            reject =itemView.findViewById(R.id.reject);
            wait =itemView.findViewById(R.id.wait);
            image = itemView.findViewById(R.id.user_image);


            cardView = itemView.findViewById(R.id.user_cardView);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                }
            });



        }
    }
}

