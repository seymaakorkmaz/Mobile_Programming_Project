package com.example.project;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Map;

public class AcceptRejectAdapter extends RecyclerView.Adapter<AcceptRejectAdapter.AcceptRejectViewHolder>{

    private ArrayList<Match> matchList;
    private Context context;
    public AcceptRejectAdapter(ArrayList<Match> matchList, Context context) {
        super();
        this.matchList = matchList;
        this.context = context;
    }
    @NonNull
    @Override
    public AcceptRejectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.accept_reject_match_list_items, parent, false);
        return new AcceptRejectAdapter.AcceptRejectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AcceptRejectAdapter.AcceptRejectViewHolder holder, int position) {
        Match match = matchList.get(position);
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();
        String id = userAuth.getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(match.getSender_id());

        // diğer kodlar...

        if (match.getSituation() == 1) {
            holder.date.setTextColor(Color.parseColor("#00AB5E"));
            holder.fullName.setTextColor(Color.parseColor("#00AB5E"));

        } else if (match.getSituation() == 2) {
            holder.date.setTextColor(Color.parseColor("#ED2626"));
            holder.fullName.setTextColor(Color.parseColor("#ED2626"));
        }


        userRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {

                    // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                    Map<String, Object> userData = document.getData();
                    holder.fullName.setText((String) userData.get("fullName"));
                    holder.date.setText(match.getDate() +" "+ match.getHour());
                    RequestOptions requestOptions = new RequestOptions();
                    requestOptions.placeholder(R.drawable.person2); // isteğe bağlı bir yer tutucu görsel ayarlandı
                    requestOptions.fitCenter();
                    Glide.with(context)
                            .setDefaultRequestOptions(requestOptions)
                            .load((String) userData.get("imageUrl"))
                            .into(holder.image);

                } else {
                    // Kullanıcı belirli ID'ye sahip değil
                }
            } else {
                // Sorgu başarısız oldu
            }
        });
    }

    @Override
    public int getItemCount() {
        return matchList.size();
    }

    public class AcceptRejectViewHolder extends RecyclerView.ViewHolder {

        TextView fullName,date;
        ImageView image;

        CardView cardView;


        public AcceptRejectViewHolder(@NonNull View itemView) {
            super(itemView);
            fullName = itemView.findViewById(R.id.user_fullname);
            image = itemView.findViewById(R.id.user_image);
            date= itemView.findViewById(R.id.date);
            cardView = itemView.findViewById(R.id.user_cardView);


            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                }
            });



        }
    }
}
