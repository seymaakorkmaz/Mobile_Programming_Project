package com.example.project;

public class Match {
    String id;
    String sender_id;
    String receiver_id;
    int situation;

    String date, hour;



    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getSeen() {
        return seen;
    }

    public void setSeen(int seen) {
        this.seen = seen;
    }

    int seen;

    public Match(String id,String sender_id, String receiver_id, int situation, String date,  String hour,int seen) {
        this.id = id;
        this.sender_id = sender_id;
        this.receiver_id = receiver_id;
        this.situation = situation;
        this.date = date;
        this.hour = hour;
        this.seen = seen;
    }

    public Match(String sender_id, String receiver_id, int situation, String date,  String hour,int seen) {
        this.sender_id = sender_id;
        this.receiver_id = receiver_id;
        this.situation = situation;
        this.date = date;
        this.hour = hour;
        this.seen = seen;
    }

    public Match(String sender_id, String receiver_id, int situation) {
        this.sender_id = sender_id;
        this.receiver_id = receiver_id;
        this.situation = situation;
    }

    public String getSender_id() {
        return sender_id;
    }

    public void setSender_id(String sender_id) {
        this.sender_id = sender_id;
    }

    public String getReceiver_id() {
        return receiver_id;
    }

    public void setReceiver_id(String receiver_id) {
        this.receiver_id = receiver_id;
    }

    public int getSituation() {
        return situation;
    }

    public void setSituation(int situation) {
        this.situation = situation;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }
}
