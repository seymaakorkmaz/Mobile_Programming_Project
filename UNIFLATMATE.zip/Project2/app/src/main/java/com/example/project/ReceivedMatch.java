package com.example.project;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Map;

public class ReceivedMatch extends Fragment {
    RecyclerView recyclerView;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ArrayList<Match> matches = new ArrayList<>();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Fragmentin görünümünü şişir
        View view = inflater.inflate(R.layout.fragment_received, container, false);
        matches.clear();

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        CollectionReference newColRef = db.collection("matches");

        newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // Sorgu başarılı oldu
                    QuerySnapshot querySnapshot = task.getResult();

                    FirebaseUser userAuth = FirebaseAuth.getInstance().getCurrentUser();
                    String id = userAuth.getUid();

                    for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {
                        System.out.println("MATCHHH");
                        // Doküman verilerini al ve kullan
                        Map<String, Object> data = documentSnapshot.getData();
                        if(((String) data.get("receiver_id")).equals(id) && Integer.parseInt(data.get("situation").toString()) == 0){
                            System.out.println("AYNIIII");

                            String documentId = documentSnapshot.getId();

                            String sender = (String) data.get("sender_id");
                            System.out.println(sender);
                            String receiver = (String) data.get("receiver_id");
                            String date = (String) data.get("date");
                            String hour = (String) data.get("hour");
                            int situation = Integer.parseInt(data.get("situation").toString());
                            int seen = Integer.parseInt(data.get("seen").toString());

                            Match match = new Match(documentId,sender,receiver,situation,date,hour,seen);
                            matches.add(match);


                        }

                    }
                    recyclerView.setAdapter(new MatchRequestsAdapter(matches,getContext()));
                } else {
                    // Sorgu başarısız oldu
                    //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                }
            }
        });



        return view;
    }

}
