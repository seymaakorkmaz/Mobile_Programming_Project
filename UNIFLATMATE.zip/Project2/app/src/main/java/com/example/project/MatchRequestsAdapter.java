package com.example.project;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Map;

public class MatchRequestsAdapter extends RecyclerView.Adapter<MatchRequestsAdapter.MatchRequestsViewHolder>{

    private ArrayList<Match> matchList;
    private Context context;

    public MatchRequestsAdapter(ArrayList<Match> matchList, Context context) {
        super();
        this.matchList = matchList;
        this.context = context;
    }

    @NonNull
    @Override
    public MatchRequestsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.match_list_items, parent, false);
        return new MatchRequestsAdapter.MatchRequestsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MatchRequestsViewHolder holder, int position) {
        Match match = matchList.get(position);
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();
        String id = userAuth.getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(match.getSender_id());

        userRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {

                    // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                    Map<String, Object> userData = document.getData();
                    holder.fullName.setText((String) userData.get("fullName"));
                    holder.date.setText(match.getDate() +" "+ match.getHour());
                    RequestOptions requestOptions = new RequestOptions();
                    requestOptions.placeholder(R.drawable.person2); // isteğe bağlı bir yer tutucu görsel ayarlandı
                    requestOptions.fitCenter();
                    Glide.with(context)
                            .setDefaultRequestOptions(requestOptions)
                            .load((String) userData.get("imageUrl"))
                            .into(holder.image);

                } else {
                    // Kullanıcı belirli ID'ye sahip değil
                }
            } else {
                // Sorgu başarısız oldu
            }
        });

    }

    @Override
    public int getItemCount() {
        return matchList.size();
    }

    public class MatchRequestsViewHolder extends RecyclerView.ViewHolder {

        TextView fullName,date;
        ImageView accept, reject, wp, mail;
        ImageView image;
        CardView cardView;


        public MatchRequestsViewHolder(@NonNull View itemView) {
            super(itemView);
            fullName = itemView.findViewById(R.id.user_fullname);
            accept = itemView.findViewById(R.id.accept);
            reject =itemView.findViewById(R.id.reject);
            image = itemView.findViewById(R.id.user_image);
            wp =itemView.findViewById(R.id.wp);
            mail = itemView.findViewById(R.id.gmail);
            date= itemView.findViewById(R.id.date_hour);

            cardView = itemView.findViewById(R.id.user_cardView);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                }
            });

            reject.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Reject");
                    builder.setMessage("Are you sure you want to reject the match request?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Match match = matchList.get(getAdapterPosition());
                            System.out.println(match.getSender_id());
                            System.out.println(match.getId());
                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            System.out.println("MATCH ID"+match.id);
                            DocumentReference docRef = db.collection("matches").document(match.getId());
                            docRef.update("situation", 2)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            sendNotification(match.getSender_id(), match.getReceiver_id()," rejected your match request");
                                            Intent intent = new Intent(context, MatchRequestsActivity.class);
                                            context.startActivity(intent);
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            // Güncelleme sırasında hata oluştu
                                        }
                                    });
                        }

                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });

                    builder.show();


                }
            });

            accept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Accept");
                    builder.setMessage("Are you sure you want to accept the match request?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Match match = matchList.get(getAdapterPosition());
                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            DocumentReference docRef = db.collection("matches").document(match.getId());
                            docRef.update("situation", 1)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            DocumentReference docRef2 = db.collection("users").document(match.getSender_id());
                                            docRef2.update("situation", 3)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            DocumentReference docRef3 = db.collection("users").document(match.getReceiver_id());
                                                            docRef3.update("situation", 3)
                                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                        @Override
                                                                        public void onSuccess(Void aVoid) {
                                                                            sendNotification(match.getSender_id(), match.getReceiver_id()," accepted your match request");
                                                                            Intent intent = new Intent(context, MatchRequestsActivity.class);
                                                                            context.startActivity(intent);
                                                                        }
                                                                    })
                                                                    .addOnFailureListener(new OnFailureListener() {
                                                                        @Override
                                                                        public void onFailure(@NonNull Exception e) {
                                                                            // Güncelleme sırasında hata oluştu
                                                                        }
                                                                    });
                                                        }
                                                    })
                                                    .addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            // Güncelleme sırasında hata oluştu
                                                        }
                                                    });



                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            // Güncelleme sırasında hata oluştu
                                        }
                                    });
                        }

                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });

                    builder.show();
                }
            });

            wp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Match match = matchList.get(getAdapterPosition());
                    FirebaseFirestore db = FirebaseFirestore.getInstance();

                    DocumentReference docRef1 = db.collection("users").document(match.getSender_id());
                    docRef1.get().addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {

                                // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                                Map<String, Object> userData = document.getData();
                                String number = (String) userData.get("phoneNumber");
                                if(number != null){
                                    String message = "Merhaba!"; // İletilecek mesajı buraya girin

                                    try {
                                        Uri uri = Uri.parse("https://api.whatsapp.com/send?phone=" + number + "&text=" + URLEncoder.encode(message, "UTF-8"));
                                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                        context.startActivity(intent);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        // Hata durumunda işlem yapabilirsiniz
                                    }
                                }

                            } else {
                                // Kullanıcı belirli ID'ye sahip değil
                            }
                        } else {
                            // Sorgu başarısız oldu
                        }
                    });



                }
            });

            mail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Match match = matchList.get(getAdapterPosition());
                    FirebaseFirestore db = FirebaseFirestore.getInstance();

                    DocumentReference docRef1 = db.collection("users").document(match.getSender_id());
                    docRef1.get().addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {

                                // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                                Map<String, Object> userData = document.getData();
                                String email = (String) userData.get("email");
                                System.out.println((String) userData.get("fullName"));
                                System.out.println(email);
                                if(email != null){
                                    System.out.println("null değil");
                                    // Alıcı e-posta adresini buraya girin
                                    String subject = "Match Request";  // E-posta konusunu buraya girin
                                    String body = "Hello,\n\nHow are you?";  // E-posta içeriğini buraya girin

                                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                                    intent.setData(Uri.parse("mailto:" + email));
                                    intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                                    intent.putExtra(Intent.EXTRA_TEXT, body);

                                    context.startActivity(Intent.createChooser(intent, "E-posta göndermek için bir uygulama seçin"));
                                }else{
                                    System.out.println("null");
                                }

                            } else {
                                // Kullanıcı belirli ID'ye sahip değil
                            }
                        } else {
                            // Sorgu başarısız oldu
                        }
                    });


                }
            });

        }
    }
    String targetUserToken;
    public void sendNotification(String targetUserId, String  senderUserId, String message){

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        DocumentReference userRef = db.collection("users").document(targetUserId);
        userRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {

                    // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                    Map<String, Object> userData = document.getData();
                    targetUserToken = (String) userData.get("token");
                } else {
                    // Kullanıcı belirli ID'ye sahip değil
                }
            } else {
                // Sorgu başarısız oldu
            }
        });


        DocumentReference userRef2 = db.collection("users").document(senderUserId);
        userRef2.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {

                    // Kullanıcı belirli ID'ye sahip olduğunda buraya gelir
                    Map<String, Object> userData = document.getData();
                    String senderUserName = (String) userData.get("fullName");

                    String title = "Match Request Response";
                    String body =  senderUserName + message;

                    FCMSend.pushNotification(context.getApplicationContext(),
                            targetUserToken,
                            title,
                            body);

                } else {
                    // Kullanıcı belirli ID'ye sahip değil
                }
            } else {
                // Sorgu başarısız oldu
            }
        });

    }
}
